Computer Graphics
FInal Project Report 3

Name: Gargi Gajjar
Student ID: 01745061
Student mail: Gargi_Gajjar@student.uml.edu
Web link: https://www.cs.uml.edu/~ggajjar/427546s2018/

1. FinalProject.html is the only file in this project. 

2. User can provide differenttransformations to each view of the house. User can apply scaling, rotation and shear transformations.
