Computer Graphics Programming Assignment 1(COMP.5460)

Name: Gargi Bhadreshkumar Gajjar
Student ID: 01745061
Email ID: Gargi_Gajjar@student.uml.edu
Web link: https://www.cs.uml.edu/~ggajjar/427546s2018/

1.	Programming Assignment1.html is the only file in this program. It has the canvas. It has 7 different shapes: 
	Line, Rectangle, Triangle, Ellipse, Oval, Polyline and Hexagon.

2.	Code draws every shape using Midpoint algorithm only. User can choose different colors and different width size. 

3.	Rubberbanding is used in each and every shapes.

4.	Every button has hover effect and pressed effect.

5.	'Clear' button clears the canvas.

6.	This program is a "Click, Move and Click program". To draw any shape user can select the shape, width size and color. Then user can click anywhere on canvas and move the cursor to draw the shape and then user can click again.

REFERENCE:
1.	https://www.w3schools.com (Used this for syntax and structures of programming language).