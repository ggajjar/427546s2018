Computer Graphics
FInal Project Report 5

Name: Gargi Gajjar
Student ID: 01745061
Student mail: Gargi_Gajjar@student.uml.edu
Web link: https://www.cs.uml.edu/~ggajjar/427546s2018/

1. FinalProject.html is the main file in this project. 

2. User can view two dimensional as well as three dimensional view of the house. There is rotating house in three dimensional view along with isometric, diametric and trimetric view. In addition there is three dimensional view of the line implemented in roject.