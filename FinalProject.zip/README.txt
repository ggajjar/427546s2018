Computer Graphics
FInal Project Report

Name: Gargi Gajjar
Student ID: 01745061
Student mail: Gargi_Gajjar@student.uml.edu
Web link: https://www.cs.uml.edu/~ggajjar/427546s2018/

1. FinalProject.html is the main file in this project. 

2. User can view two dimensional as well as three dimensional view of the house. 

3. There is rotating house in three dimensional view along with isometric, diametric and trimetric view. 

4. User can rotate the view of the house in any direction.

5. In addition there is three dimensional view of the lines.

References:
1. w3school.com for syntaxes and structures.


