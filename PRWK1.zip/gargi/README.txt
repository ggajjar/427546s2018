Computer Graphics
FInal Project Report 1

Name: Gargi Gajjar
Student ID: 01745061
Student mail: Gargi_Gajjar@student.uml.edu
Web link: https://www.cs.uml.edu/~ggajjar/427546s2018/

1. FinalProject.html is the onl;y file in this project. 

2. User can input the size of the edge for the house and it will draw the top view, front view and side view of the house.

