Computer Graphics
FInal Project Report 4

Name: Gargi Gajjar
Student ID: 01745061
Student mail: Gargi_Gajjar@student.uml.edu
Web link: https://www.cs.uml.edu/~ggajjar/427546s2018/

1. FinalProject.html is the main file in this project. 

2. User can provide scaling to the different views of the house. It will show multi view, one point view and isometric view of the house. There is one 3D rotating house object.